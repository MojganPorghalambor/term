package com.mohammadr.apitest.models;

public class PoulstarResponse<T> {
    public boolean status;
    public String message;
    public T data;
}
