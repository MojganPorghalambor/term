package com.mohammadr.apitest.api;

import com.mohammadr.apitest.models.Post;
import com.mohammadr.apitest.models.PostResponse;
import com.mohammadr.apitest.models.PoulstarResponse;

import retrofit2.Call;
import retrofit2.http.GET;

public interface PoulstarBlog {

    @GET("api/v1.0/posts")
    public Call<PoulstarResponse<PostResponse>> getPosts();

}
