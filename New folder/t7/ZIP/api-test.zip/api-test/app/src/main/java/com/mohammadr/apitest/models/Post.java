package com.mohammadr.apitest.models;

public class Post {
    public int id;
    public String title;
}
