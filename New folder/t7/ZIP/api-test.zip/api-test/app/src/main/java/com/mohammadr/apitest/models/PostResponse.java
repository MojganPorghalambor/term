package com.mohammadr.apitest.models;

import java.util.List;

public class PostResponse {
    public List<Post> posts;
}
