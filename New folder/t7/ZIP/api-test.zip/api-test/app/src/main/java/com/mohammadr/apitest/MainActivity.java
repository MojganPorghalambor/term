package com.mohammadr.apitest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.mohammadr.apitest.api.PoulstarBlog;
import com.mohammadr.apitest.models.Post;
import com.mohammadr.apitest.models.PostResponse;
import com.mohammadr.apitest.models.PoulstarResponse;


import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.moshi.MoshiConverterFactory;

public class MainActivity extends AppCompatActivity {

    private String TAG = "Main Activity";
    private TextView lblText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        lblText = findViewById(R.id.lblMessage);

        PoulstarResponse<Float> res = new PoulstarResponse<>();
        res.data = 2.3f;

        Retrofit poulstar = new Retrofit.Builder()
                .baseUrl("https://members.poulstar.com")
                .addConverterFactory(MoshiConverterFactory.create())
                .build();
        Log.e(TAG, "Sending request ");
        PoulstarBlog blogApi = poulstar.create(PoulstarBlog.class);
        Call<PoulstarResponse<PostResponse>> getPostsCall = blogApi.getPosts();
        getPostsCall.enqueue(new Callback<PoulstarResponse<PostResponse>>() {
            @Override
            public void onResponse(Call<PoulstarResponse<PostResponse>> call, Response<PoulstarResponse<PostResponse>> response) {
                Log.e(TAG, "onResponse: " + response.code());

                runOnUiThread(() -> {
                    lblText.setText(response.body().message);
                });
                Toast.makeText(MainActivity.this,
                        "" + response.body().message, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(Call<PoulstarResponse<PostResponse>> call, Throwable t) {
                Log.e(TAG, "onFailure: " + t.getMessage());
            }
        });
    }
}