from django import forms

from payment.models import PaymentType, DeliveryType, ReductionCode


class PaymentTypeForm(forms.ModelForm):
    class Meta:
        model = PaymentType
        fields = ['name', 'status', ]


class DeliveryTypeForm(forms.ModelForm):
    class Meta:
        model = DeliveryType
        fields = ['name', 'price', 'status', ]


class ReductionCodeForm(forms.ModelForm):
    class Meta:
        model = ReductionCode
        fields = ['name', 'price', 'count', 'code', 'valid_until', ]
