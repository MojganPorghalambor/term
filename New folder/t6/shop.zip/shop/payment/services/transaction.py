from payment.models import Transaction
data = [
    {
        "product_id": 4522,
        "name": "PIXEL4",
        "price": 450000,
        "quantity": 1,
        "discount": 1000
    },
    {
        "product_id": 842,
        "name": "A4 COPIMAX",
        "price": 15000,
        "quantity": 2,
        "discount": 200
    }    
]


class TransactionService:

    def add_products(data, user_id):
        cart_price = sum([i["price"]*i["quantity"] for i in data])
        transaction = Transaction.objects.create(
            user_id = user_id,
            cart_price = cart_price,
            status = 0
        )
        return transaction.id


    def redirect_to_payment(data, id_):
        transaction = Transaction.objects.get(pk=id_)
        return transaction
