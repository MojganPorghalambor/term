from django.db import models
from django.urls import reverse

from users.models import User


class PaymentType(models.Model):
    CHOICES = [
        (1, 'Cash'),
        (2, 'Online'),
        (3, 'Mobile payments'),
    ]
    name = models.CharField(max_length=1, choices=CHOICES, default=1)
    status = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse(
            'payment:payment-type-update',
            args=[self.id, ],
        )


class DeliveryType(models.Model):
    CHOICES = [
        (1, 'National Post'),
        (2, 'Pioneer Post'),
        (3, 'Tipax'),
    ]
    name = models.CharField(max_length=1, choices=CHOICES, default=1)
    price = models.DecimalField(max_digits=20, decimal_places=0, default=0)
    status = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse(
            'delivery:update',
            args=[self.id, ],
        )


class ReductionCode(models.Model):
    name = models.CharField(max_length=255)
    price = models.DecimalField(max_digits=20, decimal_places=0, default=0)
    count = models.DecimalField(max_digits=5, decimal_places=0, default=0)
    code = models.CharField(max_length=255)
    valid_until = models.DateTimeField()
    status = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse(
            'payment:reduction-code-update',
            args=[self.id, ],
        )


class Transaction(models.Model):
    CHOICES = [
        (0, "Not Paid"),
        (1, "Processing in Store"),
        (2, "Sent from Store"),
        (3, "Received by Post Officer"),
        (4, "Delivered"),
    ]
    user_id = models.ForeignKey(User, on_delete=models.CASCADE)
    transaction_id = models.CharField(max_length=255)
    payment_type_id = models.ForeignKey(PaymentType, null=True, on_delete=models.CASCADE)
    delivery_type_id = models.ForeignKey(DeliveryType, null=True, on_delete=models.CASCADE)
    reduction_code_id = models.ForeignKey(ReductionCode, null=True, on_delete=models.CASCADE)
    delivery_datetime = models.DateTimeField(null=True)
    cart_price = models.DecimalField(max_digits=20, decimal_places=0, default=0)
    total_price = models.DecimalField(max_digits=20, null=True, decimal_places=0, default=0)
    contact_info = models.CharField(max_length=255, null=True)
    status = models.SmallIntegerField(choices=CHOICES, null=True, default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
