from django.shortcuts import render, get_object_or_404

from payment.forms import PaymentTypeForm, DeliveryTypeForm, ReductionCodeForm
from payment.models import PaymentType, DeliveryType, ReductionCode, Transaction


def payment_type_read(request):
    payment_types = PaymentType.objects.all()
    return render(request, 'payment/payment_type_read.html', {'payment_types': payment_types})


def payment_type_create(request):
    form = PaymentTypeForm()
    if request.method == 'POST':
        form = PaymentTypeForm(data=request.data)
        if form.is_valid():
            form.save()
            form = PaymentTypeForm()
            return render(request, 'payment/payment_type_create.html', {'payment_type_form': form})
    return render(request, 'payment/payment_type_create.html', {'payment_type_form': form})


def payment_type_update(request, id):
    payment = get_object_or_404(
        PaymentType, pk=id
    )
    if request.method == 'POST':
        payment_type = PaymentTypeForm(request.POST, instance=payment)
        payment_type.save()
        return render(request, 'payment/payment_type_update.html', {'payment_type': payment_type})
    else:
        payment_type = PaymentTypeForm(instance=payment)
    return render(request, 'payment/payment_type_update.html', {'payment_type': payment_type})


def delivery_type_read(request):
    delivery_types = DeliveryType.objects.all()
    return render(request, 'payment/delivery_type_read.html', {'delivery_types': delivery_types})


def delivery_type_create(request):
    form = DeliveryTypeForm()
    if request.method == 'POST':
        form = DeliveryTypeForm(data=request.data)
        if form.is_valid():
            form.save()
            form = DeliveryTypeForm()
            return render(request, 'payment/delivery_type_create.html', {'delivery_type_form': form})
    return render(request, 'payment/delivery_type_create.html', {'delivery_type_form': form})


def delivery_type_update(request, id):
    delivery = get_object_or_404(
        DeliveryType, pk=id
    )
    if request.method == 'POST':
        delivery_type = DeliveryTypeForm(request.POST, instance=delivery)
        delivery_type.save()
        return render(request, 'payment/delivery_type_update.html', {'delivery_type': delivery_type})
    else:
        delivery_type = DeliveryTypeForm(instance=delivery)
    return render(request, 'payment/delivery_type_update.html', {'delivery_type': delivery_type})


def reduction_code_read(request):
    reduction_codes = ReductionCode.objects.all()
    return render(request, 'payment/reduction_code_read.html', {'reduction_codes': reduction_codes})


def reduction_code_create(request):
    form = ReductionCodeForm()
    if request.method == 'POST':
        form = ReductionCodeForm(data=request.data)
        if form.is_valid():
            form.save()
            form = ReductionCodeForm()
            return render(request, 'payment/reduction_code_create.html', {'reduction_code_form': form})
    return render(request, 'payment/reduction_code_create.html', {'reduction_code_form': form})


def reduction_code_update(request, id):
    delivery = get_object_or_404(
        ReductionCode, pk=id
    )
    if request.method == 'POST':
        reduction_code = ReductionCodeForm(request.POST, instance=delivery)
        reduction_code.save()
        return render(request, 'payment/reduction_code_update.html', {'reduction_code': reduction_code})
    else:
        reduction_code = ReductionCodeForm(instance=delivery)
    return render(request, 'payment/reduction_code_update.html', {'reduction_code': reduction_code})


def transaction_read(request, user_id):
    transactions = Transaction.objects.filter(
        user_id=user_id
    )
    return render(request, 'payment/transaction_read.html', {'transactions': transactions})


def transaction_get(request, user_id, transaction_id):
    transaction = get_object_or_404(
        Transaction, user_id=user_id, transaction_id=transaction_id
    )
    return render(request, 'payment/transaction_view.html', {'transaction': transaction})
