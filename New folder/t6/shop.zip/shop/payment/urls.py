from django.urls import path

from payment import views

app_name = 'payment'
urlpatterns = [
    path('payment/create', views.payment_type_create, name="payment-type-create"),
    path('payment/read', views.payment_type_read, name="payment-type-read"),
    path('payment/update/<int:id>', views.payment_type_update, name="payment-type-update"),
    path('delivery/create', views.delivery_type_create, name="delivery-type-create"),
    path('delivery/read', views.delivery_type_read, name="delivery-type-read"),
    path('delivery/update/<int:id>', views.delivery_type_update, name="delivery-type-update"),
    path('reductioncode/create', views.reduction_code_create, name="reduction-code-create"),
    path('reductioncode/read', views.reduction_code_read, name="reduction-code-read"),
    path('reductioncode/update/<int:id>', views.reduction_code_update, name="reduction-code-update"),
]
