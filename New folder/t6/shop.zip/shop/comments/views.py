from django.contrib.auth.models import User
from django.shortcuts import render

# Create your views here.
from comments.forms import CommentForm
from comments.models import Comment
from products.models import Products


def comments(request):
    # validation
    Comment.objects.all()

def index(request):
    comments = Comment.comments.find_by_product_id(1)
    return render(request, 'read.html', {'comments':comments})

def create(request):
    if request.method == "POST":
        form = CommentForm(request.POST)
        if form.is_valid():
            user = User.objects.get(id=1)
            product = Products.objects.get(id=1)
            f = form.save(commit=False)
            f.product = product
            f.user = user
            f.save()

    comments = Comment.comments.find_by_product_id(1)
    users = Comment.comments.find_by_user_id(1)
    replies = Comment.comments.find_by_reply_id(1)
    return render(request, 'read.html', {'comments':comments, 'users': users, 'replies': replies})
