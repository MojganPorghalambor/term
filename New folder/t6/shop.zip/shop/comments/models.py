from django.contrib.auth.models import User
from django.db import models

# Create your models here.
from products.models import Products


class CommentManager(models.Manager):
    def find_by_product_id(self, product_id):
        return super().get_queryset().filter(product=product_id)

    def find_by_user_id(self, user_id):
        return super().get_queryset().filter(user=user_id)

    def find_by_reply_id(self, reply_id):
        return super().get_queryset().filter(reply=reply_id)

class Comment(models.Model):
    title = models.CharField(max_length=50, null=False)
    body = models.TextField(null=False)
    product = models.ForeignKey(Products, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    reply = models.ForeignKey("self", on_delete=models.CASCADE, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = models.Manager()
    comments = CommentManager()
