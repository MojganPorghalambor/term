from rest_framework.routers import SimpleRouter

from products.views import ApiProductCategory

router = SimpleRouter()

router.register(r'category', ApiProductCategory,basename="category")
# router.register(r'searchproduct', ApiProduct,basename="searchproduct")

urlpatterns = router.urls