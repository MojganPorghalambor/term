from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.shortcuts import render, redirect

# Create your views here.
from rest_framework.filters import SearchFilter
from rest_framework.generics import get_object_or_404
from rest_framework.response import Response

from products import filters
from products.filters import ProductFilter
from products.forms import ProductForm, CategoryForm
from products.models import Products, ProductCategory
from rest_framework import viewsets, status, permissions

from products.serializers import ProductCategorySerializer, ProductSerializer


def showProducts(request):
    filter = filters.ProductFilter(request.GET, queryset=Products.objects.all()).qs
    paginator = Paginator(filter, 3)
    page = request.GET.get('page')
    try:
        response = paginator.page(page)
    except PageNotAnInteger:
        response = paginator.page(1)
    except EmptyPage:
        response = paginator.page(paginator.num_pages)
    return render(request, 'showProducts.html', {'filter': filter, 'response': response})


def readMore(request,id):
    product=Products.objects.get(id=id)
    return render(request, "readMore.html", {'product':product})

def addProducts(request):
    form=ProductForm()
    if request.method == "POST":
        color=request.POST['color']
        size=request.POST['size']
        weight=request.POST['weight']
        pro={"color": color,"size": size,"weight": weight}
        form=ProductForm(request.POST,request.FILES)
        if form.is_valid():
            f=form.save(commit=False)
            f.propertise=pro
            f.save()
        product = Products.objects.last()
        category_name_list = request.POST.getlist('subcategory_name')
        for category_name in category_name_list:
            category_object = ProductCategory.objects.get(name=category_name)
            product.category.add(category_object)

    return render(request,"addProducts.html",{'form':form})

def addCategory(request):
    categories=ProductCategory.objects.filter(parent_id=0)
    form=CategoryForm()
    if request.method == "POST":
        form = CategoryForm(request.POST)
        if form.is_valid():
            f=form.save(commit=False)
            parent=request.POST['parent_product']
            f.parent_id=int(parent)
            f.save()
    return render(request, "addCategoryProduct.html", {'form': form, 'categories':categories})

def dashboardShow(request):
    # products = Products.objects.all()
    categories = ProductCategory.objects.all()
    filter = filters.ProductFilter(request.GET, queryset=Products.objects.all()).qs
    paginator = Paginator(filter,3)
    page = request.GET.get('page')
    try:
        response = paginator.page(page)
    except PageNotAnInteger:
        response = paginator.page(1)
    except EmptyPage:
        response = paginator.page(paginator.num_pages)

    return render(request, "dashboardShowProduct.html", {'filter': filter,'response':response,'categories':categories})

def editProduct(request,id):
    product = Products.objects.get(id=id)
    if request.method == "POST":
        name=request.POST["name"]
        serial_id=request.POST["serial_id"]
        count=request.POST["count"]
        description=request.POST["description"]
        price=request.POST["price"]
        discount=request.POST["discount"]
        status=request.POST["status"]
        Products.objects.filter(id=id).update(name=name, serial_id=serial_id, count=count,
                       description=description, price=price, discount=discount, status=status)
    return render(request, "editProduct.html", {'product': product})
def deleteProduct(request,id):
    product = Products.objects.get(id=id)
    product.delete()
    return redirect("/products/dashboard/show/")

def searchProduct(request):
    # products=""
    # if request.method=="POST":
    #     products= Products.objects.filter(name__contains= request.POST['item'])
    #     print(request.POST['category_id'],"   ",request.POST['subcategory_name'])
    categories=ProductCategory.objects.all()
    filter = filters.ProductFilter(request.GET,queryset=Products.objects.all()).qs
    paginator = Paginator(filter, 3)
    page = request.GET.get('page')
    try:
        response = paginator.page(page)
    except PageNotAnInteger:
        response = paginator.page(1)
    except EmptyPage:
        response = paginator.page(paginator.num_pages)
    return render(request, 'searchProduct.html', {'filter': filter,'response':response,'categories':categories})


class ApiProductCategory(viewsets.ModelViewSet):
    queryset = ProductCategory.objects.all()
    permission_classes = [
        permissions.AllowAny
    ]
    serializer_class = ProductCategorySerializer

    filter_backends = (SearchFilter,)
    search_fields = ['parent_id']

# class ApiProduct(viewsets.ModelViewSet):
#     queryset = Products.objects.all()
#     permission_classes = [
#         permissions.AllowAny
#     ]
#     serializer_class = ProductSerializer
#
#     filter_backends = (SearchFilter,)
#     search_fields = ['id','name','serial_id']





