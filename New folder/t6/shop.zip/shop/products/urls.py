from django.urls import path

from products.views import *

urlpatterns = [
    path('show/', showProducts, name='show_products'),
    path('add/', addProducts, name='add_products'),
    path('category/', addCategory,name='add_category'),
    path('readmore/<int:id>', readMore, name='read_more'),
    path('dashboard/show/', dashboardShow, name='dashboard_show'),
    path('delete/<int:id>', deleteProduct, name='delete_product'),
    path('edit/<int:id>', editProduct, name='edit_product'),
    path('search/', searchProduct, name='search_product'),

]
