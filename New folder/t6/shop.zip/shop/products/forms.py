from django import forms

from products.models import Products, ProductCategory


class ProductForm(forms.ModelForm):
    class Meta():
        model = Products
        fields = ['name', 'serial_id', 'image_url' ,'count',
                  'description', 'price', 'discount', 'status']

class CategoryForm(forms.ModelForm):
    class Meta():
        model = ProductCategory
        fields = ['name']