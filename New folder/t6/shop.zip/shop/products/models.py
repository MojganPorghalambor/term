from django.db import models

class ProductCategory(models.Model):
    name=models.CharField(max_length=100)
    parent_id=models.IntegerField()
    def __str__(self):
        return self.name

class Products(models.Model):
    name = models.CharField(max_length=100)
    serial_id = models.IntegerField(default=0)
    image_url = models.ImageField(upload_to="products", default="")
    rate = models.DecimalField(max_digits=2, decimal_places=0,default=0)
    review_count=models.IntegerField(default=0)
    count = models.PositiveIntegerField(default=0)
    description=models.TextField(max_length=500)
    propertise= models.JSONField(max_length=20)
    price = models.DecimalField(max_digits=20, decimal_places=0,default=0)
    discount = models.DecimalField(max_digits=20, decimal_places=0, default=0)
    status = models.PositiveSmallIntegerField(default=0)
    category = models.ManyToManyField(ProductCategory)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)





