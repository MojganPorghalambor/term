import django_filters
from django import forms

from products.models import Products, ProductCategory


class ProductFilter(django_filters.FilterSet):
    name = django_filters.CharFilter(lookup_expr='icontains')
    # category = django_filters.ModelMultipleChoiceFilter(queryset=ProductCategory.objects.all())
    class Meta:
        model = Products
        fields = ['name', 'price','category']