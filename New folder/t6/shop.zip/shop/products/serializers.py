from rest_framework import serializers

from products.models import Products, ProductCategory


class ProductSerializer(serializers.HyperlinkedModelSerializer):
    class Meta():
        model=Products
        fields=['name','serial_id','image_url','rate','review_count','count','description','propertise','price','discount','status']

class ProductCategorySerializer(serializers.HyperlinkedModelSerializer):
    class Meta():
        model= ProductCategory
        fields=['id','name', 'parent_id']
