from django.shortcuts import redirect
from django.urls import path, include
from . import views
from django.contrib.auth import views as auth_views

from django.urls import path

from .views import RegisterAPI, LoginAPI

from knox import views as knox_views
from .views import LoginAPI
from django.urls import path

urlpatterns = [

    path('register', views.register, name='register'),
    path('profile', views.profile, name='profile'),

    path('index', views.index),


    path('api/register/', RegisterAPI.as_view(), name='register'),
    path('api/login/', LoginAPI.as_view(), name='login'),
    path('api/logout/', knox_views.LogoutView.as_view(), name='logout'),
    path('api/logoutall/', knox_views.LogoutAllView.as_view(), name='logoutall'),
]
