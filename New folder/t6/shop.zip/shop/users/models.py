from django.contrib.auth.models import User
from django.db import models


class UserProfile(User):
    f_name = models.CharField(max_length=100, null=True)
    l_name = models.CharField(max_length=100, null=True)
    status = models.PositiveSmallIntegerField(default=0)
    updated_at = models.DateTimeField(auto_now=True)


class Contact(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    phone1 = models.CharField(max_length=30, null=True)
    phone2 = models.CharField(max_length=30, null=True)
    address = models.TextField(null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
