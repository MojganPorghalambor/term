"""shop URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from . import views

urlpatterns = [
    # preview routes
    path('preview/dashboard', views.dashboard_preview, name='demo-main'),
    path('preview/', views.website_preview, name='demo-main'),

    # app routes
    path('', include('frontend.urls')),
    path('admin/', admin.site.urls),
    path('users/', include('users.urls')),
    path('products/', include('products.urls')),
    path('promotions/', include('promotions.urls')),
    path('payment/', include('payment.urls')),
    path('comments/', include('comments.urls')),

    # api routes v0.1
    path('api/v1.0/cart/', include('cart.urls')),
    path('api/v1.0/users/', include('users.apis')),
    path('api/v1.0/products/', include('products.apis')),
    path('api/v1.0/promotions/', include('promotions.apis')),
    path('api/v1.0/payment/', include('payment.apis')),
    path('api/v1.0/comments/', include('comments.apis')),
    path('api/v1.0/cart/', include('cart.apis')),

] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT) \
  + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
