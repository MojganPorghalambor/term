from django.shortcuts import render


def website_preview(request):
    return render(request, 'preview-website.html')


def dashboard_preview(request):
    return render(request, 'preview-dashboard.html')