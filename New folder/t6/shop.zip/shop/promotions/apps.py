from django.apps import AppConfig


class PromotionsConfig(AppConfig):
    name = 'promotions'
