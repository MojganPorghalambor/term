# Shop
Market website implemented with django framework

#Database Config

|Host        |Port       |User        |Pass       |DB name   |
|------------|-----------|------------|-----------|----------|
|localhost   |3306       |poulstar    |poulstar   |shop      |

# Apps

|App name         |Assignee        |
|-----------------|----------------|
|User             |Mahan Kabir     |
|Comment          |Mahan Kabir     |
|Product          |Fatemeh Motamed |
|Payment          |Sina Bakhshandeh|
|Shopping Cart    |Ailin Hajipoor  |
|ProductPromotion |Rahimizadeh     | 

## 1. User
Assignee: Mahan Kabir

|Models  |
|--------|
|User    |
|Contact |
|Token   |

###### ER sketchpad: files/User-Comment.sketchpad

## 2. Comment
Assignee: Mahan Kabir

|Models  |
|--------|
|Comment |

###### ER sketchpad: files/User-Comment.sketchpad

## 3. Product
Assignee: Fatemeh Motamed

|Models                   |
|-------------------------|
|Product                  |
|ProductCategory          |
|ProductProductCategory   |

###### ER sketchpad: files/Product.sketchpad

## 4. Payment
Assignee: Sina Bakhshandeh

|Models         |
|---------------|
|Transaction    |
|ReductionCode  |
|PaymentType    |
|DeliveryType   |

###### ER sketchpad: files/Transaction.sketchpad

## 5. Shopping Cart
Assignee: Ailin Hajipoor

## 6. Product Promotion
Assignee: Rahimizadeh

|Models            |
|------------------|
|ProductPromotion  |
